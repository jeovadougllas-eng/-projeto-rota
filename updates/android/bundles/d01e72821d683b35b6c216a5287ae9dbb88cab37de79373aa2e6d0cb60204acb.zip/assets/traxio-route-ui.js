/* One controller for client selection, readiness, origins and road-route transactions. */
'use strict';
document.addEventListener('DOMContentLoaded',()=>{
 const el=id=>document.getElementById(id), P=TraxioPlanner;
 let generation=0,controller=null,manualOrigin=null,manualDraft=null,checking=false,selectionKey=null,lastSignature='',activeFingerprint='',activeSelection='',consentResolve=null;
 let preparedRoute=null,calculationPlan=null,dialogPlanSignature='',gpsOrigin=null;const matrixCache=new Map();
 const state={phase:'awaiting-selection',excluded:[]};
 const labels={'ready':'Pronto para calcular','awaiting-selection':'Aguardando seleção','awaiting-origin':'Aguardando origem','checking-locations':'Verificando localizações','calculating':'Calculando rota','calculated':'Rota calculada','partial':'Rota parcialmente calculada','location-error':'Falha de localização','communication-error':'Falha de comunicação','impossible':'Nenhuma rota possível','review':'Revisão necessária'};
 function node(tag,id,text){const n=document.createElement(tag);if(id)n.id=id;if(text)n.textContent=text;return n;}
 const workspace=document.querySelector('#mapa .workspace'),side=document.querySelector('.workspace-side'),planner=document.querySelector('.workspace-route'),mapPanel=document.querySelector('.workspace-map');
 const panel=node('details','routePlannerPanel'),summary=node('summary',null,'Planejar visitas');panel.open=true;panel.append(summary,side,planner);workspace.prepend(panel);
 const steps=node('p','routeSteps','Selecionar clientes → Definir origem → Escolher critério → Calcular → Conferir rota → Iniciar navegação');summary.after(steps);
 const badge=node('p','plannerState');badge.setAttribute('role','status');badge.setAttribute('aria-live','polite');el('routeResult').before(badge);
 el('routeResult').setAttribute('role','status');el('routeResult').setAttribute('aria-live','polite');
 el('selectAllClients').textContent='Selecionar resultados filtrados';el('priorityFilters').after(el('mapClientListDisclosure'));
 const all=node('button','selectEntirePortfolio','Selecionar toda a carteira');all.type='button';all.className='secondary';el('selectNoClients').after(all);
 all.onclick=()=>{for(const c of clients)selectedIds.add(c.id);syncRouteChoices();renderWorkspace();refresh();};
 const readiness=node('div','routeReadiness');readiness.setAttribute('role','status');el('selectedCount').after(readiness);
 const confirmedOnly=node('button','routeConfirmedOnly');confirmedOnly.type='button';confirmedOnly.hidden=true;readiness.after(confirmedOnly);confirmedOnly.onclick=()=>calculate(document.querySelector('input[name="routeStrategy"]:checked')?.value||'distance');
 const review=node('details','locationReview'),reviewSummary=node('summary',null,'Revisar localizações'),reviewList=node('div','locationReviewList');
 const retry=node('button','retrySelectedLocations','Tentar localizar pendentes novamente');retry.type='button';retry.className='secondary';
 review.append(reviewSummary,reviewList,retry);side.append(review);
 const secondary=node('details','adHocDisclosure'),adHocSummary=node('summary',null,'Destino avulso');secondary.append(adHocSummary,el('traxioAvulso'));planner.append(secondary);
 const routeOrderDisclosure=node('details','routeOrderDisclosure');routeOrderDisclosure.append(node('summary',null,'Conferir e ajustar sequência'),el('routeOrder'));document.querySelector('.route-summary').append(routeOrderDisclosure);
 const stopsDisclosure=node('details','navigationStopDisclosure');stopsDisclosure.append(node('summary',null,'Paradas e visitas'),el('liveStopList'));el('liveNextStop').after(stopsDisclosure);
 document.querySelector('.route-summary').append(el('liveNavigation'));
 const actionBar=document.querySelector('.planner-main>.row');actionBar.id='routeActionBar';actionBar.append(el('liveStart'));panel.append(actionBar);el('liveStart').hidden=true;
 new MutationObserver(()=>{el('liveStart').hidden=el('liveNavigation').hidden||!!window.TraxeloNavigation?.isTracking();}).observe(el('liveNavigation'),{attributes:true,attributeFilter:['hidden']});
 el('traxioAvulso').querySelector('h3').textContent='Destino avulso';
 const trace=document.querySelector('.approved-trace-route');
 if(trace){trace.onclick=()=>{el('calcRoute').click();};trace.hidden=true;}
 el('origin').add(new Option('Endereço ou ponto no mapa','manual'));
 const originForm=node('div','manualOriginFields');
 originForm.hidden=true;
 originForm.innerHTML='<label for="routeOriginAddress">Endereço da origem</label><div class="row"><input id="routeOriginAddress" placeholder="Rua, número, bairro, cidade, UF" autocomplete="street-address"><button type="button" id="findRouteOrigin">Buscar origem</button><button type="button" id="pickRouteOrigin" class="secondary">Marcar origem no mapa</button></div><p id="routeOriginStatus" role="status">Informe o endereço completo ou confirme um ponto no mapa.</p><div id="routeOriginSuggestions"></div><button type="button" id="confirmRouteOrigin" hidden>Confirmar este ponto como origem</button>';
 el('origin').after(originForm);
 const gpsPanel=node('div','gpsOriginPanel'),gpsLabel=node('p','gpsOriginLabel','Sua posição será fixada ao calcular. Atualize-a quando quiser mudar o ponto de partida.'),gpsRefresh=node('button','refreshGpsOrigin','Atualizar minha posição');gpsRefresh.type='button';gpsRefresh.className='secondary';gpsPanel.append(gpsLabel,gpsRefresh);originForm.after(gpsPanel);
 function showGpsOrigin(){gpsPanel.hidden=el('origin').value!=='gps';gpsLabel.textContent=gpsOrigin?'Origem GPS definida: '+gpsOrigin.lat.toFixed(6)+', '+gpsOrigin.lon.toFixed(6)+(Number.isFinite(gpsOrigin.accuracy)?' · precisão ±'+Math.round(gpsOrigin.accuracy)+' m':'')+'. Esta origem será mantida até você atualizá-la.':'Sua posição será fixada ao calcular. Atualize-a quando quiser mudar o ponto de partida.';}
 async function roadDistances(nodes,signal){const key=JSON.stringify(nodes.map(p=>[Number(p.lat),Number(p.lon)])),cached=matrixCache.get(key);if(cached&&Date.now()-cached.at<600000)return cached.matrix;const matrix=await roadMatrix(nodes,{signal});signal.throwIfAborted();matrixCache.set(key,{at:Date.now(),matrix});if(matrixCache.size>5)matrixCache.delete(matrixCache.keys().next().value);return matrix;}

 const citySearch=node('input','regionCitySearch');citySearch.type='search';citySearch.placeholder='Buscar cidade';citySearch.setAttribute('aria-label','Buscar cidade');el('regionCity').before(citySearch);
 const districtSearch=node('input','regionNeighborhoodSearch');districtSearch.type='search';districtSearch.placeholder='Buscar bairro';districtSearch.setAttribute('aria-label','Buscar bairro');el('regionNeighborhoods').before(districtSearch);
 function applyRegionSearch(){const cq=norm(citySearch.value),dq=norm(districtSearch.value);for(const o of el('regionCity').options)o.hidden=o.value!=='all'&&o.value!==el('regionCity').value&&!norm(o.textContent).includes(cq);for(const label of el('regionNeighborhoods').children)label.hidden=!norm(label.textContent).includes(dq);}
 citySearch.oninput=applyRegionSearch;districtSearch.oninput=applyRegionSearch;
 new MutationObserver(applyRegionSearch).observe(el('regionNeighborhoods'),{childList:true});
 function originSignature(){return JSON.stringify([el('origin').value,manualOrigin,document.querySelector('input[name="routeStrategy"]:checked')?.value||'distance']);}
 function restingPhase(){return !selectedIds.size?'awaiting-selection':el('origin').value==='manual'&&!manualOrigin?'awaiting-origin':'ready';}
 function signature(){return P.signature(clients,selectedIds,originSignature());}
 function current(run){return run===generation&&!controller?.signal.aborted;}
 function updateButtons(){
  const busy=routeBusy;
  el('calcRoute').disabled=busy;el('generateSuggestion').disabled=busy;
  el('roadRoute').disabled=busy||!(lastRoute||preparedRoute);confirmedOnly.disabled=busy;
  planner.setAttribute('aria-busy',String(busy));window.TraxeloMapActions?.refresh();window.TraxeloWorkspace?.routeReady();
 }
 function phase(name,message){state.phase=name;badge.textContent=labels[name]||name;badge.dataset.phase=name;el('mapa').dataset.routeState=name;if(message)el('routeResult').textContent=message;updateButtons();}

 function cancel(message){
  generation++;controller?.abort();controller=null;routeBusy=false;routeLookupBusy=false;
  if(consentResolve){consentResolve(false);consentResolve=null;}if(dialog.open)dialog.close();
  window.traxioResetNavigation?.();lastRoute=null;preparedRoute=null;calculationPlan=null;activeFingerprint='';activeSelection='';window.traxioPendingTrip=null;
  el('saveCompletedRoute')?.remove();clearRouteVisual();el('routeOrder').replaceChildren();
  phase(restingPhase(),message||'Planejamento alterado. Confira a origem e calcule novamente.');
 }
 function selectedInOrder(){const byId=new Map(clients.map(c=>[String(c.id),c]));return [...selectedIds].map(id=>byId.get(String(id))).filter(Boolean);}
 function persist(){
  if(!selectionKey)return;
  try{localStorage.setItem(selectionKey,JSON.stringify([...selectedIds]));}catch{el('mapStatus').textContent='Não foi possível salvar a seleção neste dispositivo.';}
 }
 async function hydrate(){
  const response=await authClient?.auth.getSession();const user=response?.data?.session?.user;
  if(!user)return;
  const key=RotaMapaPortfolioScope.key('traxio.route.selection.v1:'+user.id,user.id);
  if(selectionKey===key)return;
  selectionKey=key;let stored=null;try{stored=JSON.parse(localStorage.getItem(key)||'null');}catch{}
  if(Array.isArray(stored)){selectedIds=new P.IdSet(stored);selectionInitialized=true;syncRouteChoices();renderWorkspace();}
  lastSignature=signature();refresh();
 }
 let wasLocked=document.body.classList.contains('auth-locked');
 const authObserver=new MutationObserver(()=>{const locked=document.body.classList.contains('auth-locked');if(locked===wasLocked)return;wasLocked=locked;if(locked){selectionKey=null;gpsOrigin=null;manualOrigin=null;matrixCache.clear();selectedIds.clear();cancel('Entre na sua conta para planejar as visitas.');}else hydrate().catch(()=>{});});
 authObserver.observe(document.body,{attributes:true,attributeFilter:['class']});hydrate().catch(()=>{});
 function refresh(){
  const fingerprint=signature();
  if(lastSignature&&fingerprint!==lastSignature){
   const plan=lastRoute||preparedRoute||calculationPlan;
   const planIds=plan?[...plan.points.map(c=>c.id),...(plan.start?.id!==undefined?[plan.start.id]:[])]:[];
   const changedPlan=plan&&(activeSelection!==JSON.stringify([...selectedIds].sort())||activeFingerprint!==P.signature(clients,planIds,originSignature()));
   const changedReview=dialog.open&&dialogPlanSignature!==JSON.stringify([[...selectedIds].sort(),originSignature()]);
   if(changedReview||changedPlan||routeBusy&&!plan&&!dialog.open)cancel('Seleção, endereço ou origem alterados. Calcule o trajeto atualizado.');
  }
  lastSignature=fingerprint;persist();
  const result=P.partition(clients,selectedIds);
  readiness.textContent=result.total+' selecionados · '+result.ready.length+' aptos · '+result.unverified.length+' não verificados · '+result.blocked.length+' pendentes'+(result.unloaded.length?' · '+result.unloaded.length+' aguardando sincronização':'');
  summary.textContent='Planejar visitas · '+result.total+' selecionados · '+result.ready.length+' aptos';
  const pending=result.blocked.length+result.unverified.length+result.unloaded.length;
  confirmedOnly.hidden=!result.ready.length||!pending||!!lastRoute;confirmedOnly.textContent='Calcular rota com '+result.ready.length+' confirmado(s) · '+pending+' pendente(s) ficam de fora';updateButtons();
  const shouldBuild=JSON.stringify([result.unloaded,[...result.blocked,...result.unverified].map(c=>[c.id,c.locationCandidate?.error,geoCandidates.get(c.id)?.error,c.locationVerification])]);
  if(reviewList.dataset.content!==shouldBuild){
   reviewList.dataset.content=shouldBuild;reviewList.replaceChildren();
   for(const c of [...result.blocked,...result.unverified]){
    const row=node('article');row.className='location-review-row';const status=P.location(c);
    row.append(node('strong',null,c.name),node('p',null,(status.kind==='unverified'?'Coordenadas importadas ou não verificadas.':geoCandidates.get(c.id)?.error||c.locationCandidate?.error||'Sem localização exata confirmada.')+' '+(c.address||'Endereço ausente')));
    const edit=node('button',null,'Corrigir endereço / confirmar no mapa');edit.type='button';edit.className='secondary';edit.onclick=()=>window.traxeloReviewClient?window.traxeloReviewClient(c.id):openClientLocation(c.id,c.locationCandidate||geoCandidates.get(c.id));row.append(edit);reviewList.append(row);
   }
   for(const id of result.unloaded)reviewList.append(node('p',null,'Cliente '+id+': aguardando registro da sincronização. A seleção foi preservada.'));
  }
  reviewSummary.textContent='Revisar localizações ('+(result.blocked.length+result.unverified.length+result.unloaded.length)+')';
  retry.disabled=checking||!result.blocked.length;
  if(!selectedIds.size&&!routeBusy&&!lastRoute)phase('awaiting-selection','Selecione clientes para começar.');
  else if(selectedIds.size&&!routeBusy&&!lastRoute&&state.phase==='awaiting-selection')phase(restingPhase(),'Confira a origem e escolha o critério para organizar as visitas.');
  renderMarkers();
 }
 new MutationObserver(refresh).observe(el('selectedCount'),{childList:true,characterData:true,subtree:true});
 const originalRenderWorkspace=renderWorkspace;
 renderWorkspace=function(){originalRenderWorkspace();refresh();};
 const originalRender=render;
 render=function(){originalRender();refresh();};
 // Review is explicit; geocoder candidates never silently become verified clients.
 retry.onclick=async()=>{
  if(checking)return;checking=true;const ids=P.partition(clients,selectedIds).blocked.map(c=>c.id);
  for(const id of ids){geoCandidates.delete(id);const c=clients.find(c=>String(c.id)===String(id));if(c)delete c.locationCandidate;}
  phase('checking-locations','Consultando CEP, logradouro e número. As buscas respeitam os limites do serviço.');
  refresh();try{await queueClientGeocode(ids,{force:true});}finally{checking=false;if(!routeBusy&&!lastRoute&&!preparedRoute)phase('review','Verificação terminada. Você pode calcular com os confirmados e revisar os demais depois.');refresh();}
 };
 const dialog=node('dialog','partialRouteDialog');dialog.setAttribute('aria-labelledby','partialRouteTitle');
 dialog.innerHTML='<h2 id="partialRouteTitle">Conferir clientes da rota</h2><p id="partialRouteMessage"></p><ul id="partialRouteClients"></ul><label id="unverifiedConsentLabel"><input type="checkbox" id="includeUnverifiedLocations"> Incluir também as coordenadas não verificadas, ciente de que podem estar incorretas.</label><div class="row"><button type="button" id="confirmPartialRoute">Calcular com os clientes indicados</button><button type="button" id="cancelPartialRoute" class="secondary">Corrigir localizações</button></div>';
 document.body.append(dialog);
 dialog.addEventListener('cancel',()=>{consentResolve?.(false);consentResolve=null;});
 function confirmSubset(report){
  phase('review','Há localizações que exigem revisão. Confirme os clientes que serão usados na rota.');
  el('partialRouteMessage').textContent=report.ready.length+' com localização confirmada; '+report.unverified.length+' com coordenadas não verificadas. '+(report.blocked.length+report.unloaded.length)+' sem localização utilizável serão excluídos. As coordenadas não verificadas ficam de fora por padrão; inclua-as apenas após conferir. Usá-las não altera sua classificação no cadastro.';
  el('partialRouteClients').replaceChildren();
  for(const c of [...report.blocked,...report.unverified]){const li=node('li',null,c.name+': '+(P.location(c).consent?'coordenadas não verificadas; excluído, salvo autorização na opção abaixo':'sem localização confirmada, excluído'));el('partialRouteClients').append(li);}
  for(const id of report.unloaded)el('partialRouteClients').append(node('li',null,id+': registro ainda não carregado, excluído'));
  el('includeUnverifiedLocations').checked=false;el('unverifiedConsentLabel').hidden=!report.unverified.length;
  function updateConsent(){const count=report.ready.length+(el('includeUnverifiedLocations').checked?report.unverified.length:0);el('confirmPartialRoute').disabled=!count;el('confirmPartialRoute').textContent='Calcular com '+count+' cliente(s) indicado(s)';}
  el('includeUnverifiedLocations').onchange=updateConsent;updateConsent();
  dialogPlanSignature=JSON.stringify([[...selectedIds].sort(),originSignature()]);dialog.showModal();
  return new Promise(resolve=>{consentResolve=choice=>resolve(choice?{...choice,approvedIds:[...report.ready,...(choice.allowUnverified?report.unverified:[])].map(c=>c.id)}:false);});
 }
 el('confirmPartialRoute').onclick=()=>{const done=consentResolve;consentResolve=null;dialog.close();done?.({allowUnverified:el('includeUnverifiedLocations').checked});};
 el('cancelPartialRoute').onclick=()=>{const done=consentResolve;consentResolve=null;dialog.close();review.open=true;done?.(false);review.scrollIntoView({block:'nearest'});};
 function manualChanged(){window.traxioPickingOrigin=false;originMarker?.remove();manualOrigin=null;manualDraft=null;el('confirmRouteOrigin').hidden=true;cancel('Confirme a nova origem e calcule novamente.');lastSignature=signature();}
 el('routeOriginAddress').oninput=manualChanged;
 el('origin').addEventListener('change',()=>{gpsOrigin=null;showGpsOrigin();window.traxioPickingOrigin=false;if(el('origin').value!=='manual')originMarker?.remove();originForm.hidden=el('origin').value!=='manual';cancel('Origem alterada. Confira os dados e calcule novamente.');lastSignature=signature();});
 el('findRouteOrigin').onclick=async()=>{
  manualChanged();const q=el('routeOriginAddress').value.trim();if(q.length<8){el('routeOriginStatus').textContent='Informe rua, número, cidade e UF.';return;}
  el('routeOriginStatus').textContent='Buscando a origem…';const text=q,run=generation;
  try{
   const result=await TraxioGeo.locate({address:q},{token:await geoToken()});
   if(run!==generation||text!==el('routeOriginAddress').value.trim())return;
   const p=result.best;
   if(!p){el('routeOriginStatus').textContent=result.reason||'Origem não encontrada. Confira os dados ou marque o ponto no mapa.';return;}
   manualDraft={lat:p.lat,lon:p.lon,name:q};el('routeOriginStatus').textContent=result.status==='matched'?'Número encontrado. Confirme esta origem.':'Sugestão aproximada. Confira o marcador no mapa antes de confirmar a origem.';
   initMap();if(map&&window.maplibregl){originMarker?.remove();originMarker=new maplibregl.Marker({color:'#f97316',draggable:true}).setLngLat([p.lon,p.lat]).addTo(map);originMarker.on('dragend',()=>{const p=originMarker.getLngLat();manualDraft={lat:p.lat,lon:p.lng,name:q};});map.flyTo({center:[p.lon,p.lat],zoom:17});}
   el('confirmRouteOrigin').hidden=false;el('routeOriginAddress').blur();
  }catch(e){if(run===generation)el('routeOriginStatus').textContent='Falha ao buscar origem: '+e.message;}
 };
 let originMarker=null;
 el('pickRouteOrigin').onclick=()=>{
  initMap();if(!map){el('routeOriginStatus').textContent='Mapa indisponível. Confira a conexão.';return;}
  manualChanged();window.traxioPickingOrigin=true;el('routeOriginStatus').textContent='Toque na entrada do local no mapa e confirme a origem.';mapPanel.scrollIntoView({block:'nearest'});
 };
 const originMapInit=initMap;
 initMap=function(){originMapInit();if(map&&!map.__traxioOrigin){map.__traxioOrigin=true;map.on('click',e=>{if(!window.traxioPickingOrigin)return;manualDraft={lat:e.lngLat.lat,lon:e.lngLat.lng,name:'Origem confirmada no mapa'};originMarker?.remove();originMarker=new maplibregl.Marker({color:'#f97316'}).setLngLat([manualDraft.lon,manualDraft.lat]).addTo(map);el('confirmRouteOrigin').hidden=false;el('routeOriginStatus').textContent='Ponto selecionado. Confirme para usá-lo como origem.';});}};
 el('confirmRouteOrigin').onclick=()=>{if(!manualDraft)return;manualOrigin={...manualDraft};window.traxioPickingOrigin=false;cancel('Origem confirmada. Organize as visitas.');lastSignature=signature();el('routeOriginStatus').textContent='Origem confirmada: '+manualOrigin.lat.toFixed(6)+', '+manualOrigin.lon.toFixed(6);el('confirmRouteOrigin').hidden=true;};
 el('myLocation').onclick=async()=>{
  phase('awaiting-origin','Obtendo sua localização…');const run=generation;
  try{const point=await requestGPS();if(run!==generation)return;gpsOrigin={...point};el('origin').value='gps';showGpsOrigin();originForm.hidden=true;cancel('Origem por GPS definida. Organize as visitas.');lastSignature=signature();initMap();map?.flyTo({center:[point.lon,point.lat],zoom:15});}
  catch(e){phase('awaiting-origin','GPS indisponível: '+e.message+'. Autorize a localização ou escolha uma origem manual.');}
 };
 gpsRefresh.onclick=()=>el('myLocation').click();showGpsOrigin();
 async function waitForGeometry(geometry,signal){
  initMap();if(!map||!window.maplibregl)throw Error('Mapa indisponível. Confira a conexão e tente novamente.');
  if(!map.isStyleLoaded()&&!map.getStyle()?.layers?.length)await new Promise((resolve,reject)=>{
   const timeout=setTimeout(()=>finish(Error('O mapa não terminou de carregar.')),20000);
   function ready(){finish();}function aborted(){finish(new DOMException('Cancelado','AbortError'));}
   function finish(error){clearTimeout(timeout);map.off?.('style.load',ready);map.off?.('load',ready);signal.removeEventListener('abort',aborted);error?reject(error):resolve();}
   map.once('style.load',ready);map.once('load',ready);signal.addEventListener('abort',aborted,{once:true});if(signal.aborted)aborted();
  });
  signal.throwIfAborted();displayRoadGeometry(geometry);
  if(!map.getSource('route')||!map.getLayer('route-line'))throw Error('Não foi possível renderizar o itinerário no mapa.');
 }
 async function calculate(strategy='distance',{existing=null,destination=null}={}){
  if(routeBusy){el('mapStatus').textContent='Já há uma operação em andamento. Aguarde ou limpe o trajeto para cancelar.';return;}
  cancel('Verificando os clientes selecionados…');const run=generation;controller=new AbortController();const signal=controller.signal;
  routeBusy=true;phase('checking-locations','Verificando as localizações antes de calcular…');
  try{
   let report=destination?{ready:[destination],blocked:[],unverified:[],unloaded:[],total:1}:existing?P.partition(existing.points,existing.points.map(c=>c.id),{allowUnverified:existing.allowUnverified}):P.partition(selectedInOrder(),selectedIds);
   if(!report.total){phase('awaiting-selection','Selecione pelo menos um cliente.');return;}
   let consent=false;
   if(!existing&&(report.blocked.length||report.unverified.length||report.unloaded.length)){consent=await confirmSubset(report);if(!current(run))return;if(!consent){phase('location-error','Corrija as localizações indicadas ou confirme uma rota com os clientes aptos.');return;}}
   const allowUnverified=!!(existing?.allowUnverified||consent?.allowUnverified);
   if(!destination&&!existing)report=P.partition(selectedInOrder(),consent?consent.approvedIds:selectedIds,{allowUnverified});
   if(existing&&report.ready.length!==existing.points.length){phase('location-error','As localizações da sequência mudaram. Organize as visitas novamente.');return;}
   const points=report.ready;
   if(!points.length){review.open=true;phase('location-error','Nenhum cliente selecionado possui localização utilizável. Corrija os endereços ou confirme os pontos no mapa.');return;}
   const approved=new P.IdSet(points.map(c=>c.id));
   state.excluded=existing?[...existing.excluded]:destination?[]:[...selectedIds].filter(id=>!approved.has(id)).map(String);
   calculationPlan={points,start:existing?.start};activeSelection=JSON.stringify([...selectedIds].sort());
   const planSignature=()=>P.signature(clients,[...points.map(c=>c.id),...(existing?.start?.id!==undefined?[existing.start.id]:[])],originSignature());
   const snapshot=planSignature();activeFingerprint=snapshot;let start;phase('awaiting-origin','Verificando a origem da rota…');
   if(destination){if(!valid(destination.lat,destination.lon)){phase('location-error','Confirme um destino com coordenadas válidas.');return;}try{start=await requestGPS();if(current(run)){gpsOrigin={...start};showGpsOrigin();}}catch(e){phase('awaiting-origin','GPS indisponível: '+e.message);return;}}
   else if(existing)start=existing.start;
   else if(el('origin').value==='manual'){if(!manualOrigin){phase('awaiting-origin','Busque e confirme o endereço ou marque a origem no mapa.');return;}start={...manualOrigin};}
   else if(el('origin').value==='gps'){try{start=gpsOrigin?{...gpsOrigin}:await requestGPS();if(current(run)){gpsOrigin={...start};showGpsOrigin();}}catch(e){phase('awaiting-origin','GPS indisponível: '+e.message+'. Autorize a localização ou escolha uma origem manual.');return;}}
   else start=points[0];
   if(!current(run)||snapshot!==planSignature())return;
   const nodes=existing?[start,...existing.points]:[start,...TraxeloNavigationModel.canonical(points.filter(c=>!(start.id!==undefined&&String(c.id)===String(start.id))))];
   if(nodes.length<2){phase('impossible','A origem já é o único cliente selecionado. Escolha GPS ou uma origem manual para traçar o percurso.');return;}
   phase('calculating','Calculando sequência e trajeto pelas ruas…');
   const matrix=existing||destination?null:await roadDistances(nodes,signal);if(!current(run))return;
   const arranged=existing?existing.points:destination?[destination]:optimizeStrategy(nodes,matrix,strategy).slice(1).map(i=>nodes[i]);
   preparedRoute={start,points:arranged,excluded:[...state.excluded],strategy,allowUnverified};
   const road=await fetchRoadRoute([start,...arranged],{signal});
   if(!current(run)||snapshot!==planSignature())return;
   await waitForGeometry(road.geometry,signal);if(!current(run))return;
   lastRoute={...preparedRoute};preparedRoute=null;calculationPlan=null;activeSelection=JSON.stringify([...selectedIds].sort());activeFingerprint=P.signature(clients,[...arranged.map(c=>c.id),...(start.id!==undefined?[start.id]:[])],originSignature());showOrder(arranged);renderMarkers();
   window.traxioBeginNavigation?.(arranged,road.geometry,{legs:road.legs,origin:start});
   const partial=state.excluded.length>0;
   phase(partial?'partial':'calculated',(destination?(strategy==='single'?'Visita individual · Trajeto por ruas: ':'Destino avulso · Trajeto por ruas: '):'Trajeto por ruas: ')+(road.distance/1000).toFixed(1)+' km · '+Math.round(road.duration/60)+' min estimados · '+arranged.length+' paradas'+(start.id!==undefined?' + cliente de origem':'')+'. '+(partial?state.excluded.length+' clientes excluídos com sua confirmação. ':'')+(allowUnverified?'Coordenadas não verificadas incluídas com sua confirmação. ':'')+'Sem trânsito em tempo real.');
   window.traxioPendingTrip={distanceKm:road.distance/1000,durationMin:Math.round(road.duration/60),names:arranged.map(c=>c.name),strategy,at:new Date().toISOString(),excluded:[...state.excluded]};
   window.traxioShowSaveTrip?.();window.TraxeloWorkspace?.routeReady();map?.resize();mapPanel.scrollIntoView({block:'start',behavior:'smooth'});return lastRoute;
  }catch(e){
   if(!current(run)||signal.aborted)return;
   window.traxioResetNavigation?.();lastRoute=null;calculationPlan=null;clearRouteVisual();if(preparedRoute)showOrder(preparedRoute.points);else el('routeOrder').replaceChildren();
   const impossible=/ligação|ligacao|rodoviário não encontrado|rodoviario|origem e um destino/i.test(e.message);
   phase(impossible?'impossible':'communication-error','Rota não calculada: '+e.message+'. '+(preparedRoute?'A sequência está pronta. Toque em Traçar pelas ruas para tentar novamente. ':'Confira a conexão e tente novamente. ')+'Nenhum itinerário foi confirmado.');
  }finally{if(current(run)){routeBusy=false;controller=null;calculationPlan=null;updateButtons();}}
 }
 el('suggestToggle').setAttribute('aria-controls','strategyPanel');el('suggestToggle').setAttribute('aria-expanded','false');
 el('suggestToggle').onclick=()=>{const strategies=el('strategyPanel');strategies.hidden=!strategies.hidden;el('suggestToggle').setAttribute('aria-expanded',String(!strategies.hidden));if(!strategies.hidden){el('routeResult').textContent='Escolha o critério e toque em Gerar sugestão agora.';strategies.scrollIntoView({block:'center',behavior:'smooth'});}};
 document.querySelectorAll('input[name="routeStrategy"]').forEach(input=>input.addEventListener('change',()=>{cancel('Critério alterado. Organize as visitas para atualizar o percurso.');lastSignature=signature();}));
 el('clearRoute').onclick=()=>{cancel('Trajeto limpo. A seleção de clientes foi preservada.');lastSignature=signature();};
 // Manual stop ordering invalidates street geometry until explicitly retraced.
 swapStops=function(a,b){
  const plan=lastRoute||preparedRoute;if(!plan||!plan.points[a]||!plan.points[b])return;
  [plan.points[a],plan.points[b]]=[plan.points[b],plan.points[a]];preparedRoute={...plan};lastRoute=null;
  window.traxioResetNavigation?.();window.traxioPendingTrip=null;el('saveCompletedRoute')?.remove();el('liveNavigation').hidden=true;
  clearRouteVisual();showOrder(plan.points);phase('ready','Ordem ajustada. Toque em Traçar pelas ruas para confirmar o novo itinerário.');
 };

 async function singleClient(id){
  const c=clients.find(c=>String(c.id)===String(id));if(!c)return false;
  if(!P.location(c).ready){window.traxeloReviewClient?.(c.id);return false;}
  if(window.TraxeloNavigation?.isTracking()){if(!confirm('Trocar a navegação atual por uma rota somente até '+c.name+'? As visitas já registradas serão preservadas.'))return false;window.TraxeloNavigation.finish('partial');}
  el('origin').value='gps';gpsOrigin=null;originForm.hidden=true;showGpsOrigin();selectedIds=new P.IdSet([c.id]);selectionInitialized=true;syncRouteChoices();renderWorkspace();switchTab('mapa');
  const result=await calculate('single',{destination:{...c,lat:Number(c.lat),lon:Number(c.lon)}});
  if(!result)return false;window.TraxeloNavigation?.start();return true;
 }
 async function openSaved(saved,{currentOrigin=true}={}){
  const localOwner=localStorage.getItem('traxio_sync_owner_v29'),activeOwner=window.TraxeloWorkspace?.getStore()?.owner;if(localOwner&&localOwner!==activeOwner)throw Error('A carteira deste navegador pertence a outra conta. Use um perfil separado antes de abrir esta rota.');
  if(window.TraxeloNavigation?.isTracking()&&!confirm('Trocar a navegação atual pela rota salva? As visitas registradas serão preservadas.'))return false;
  let resolved=TraxeloPremiumModel.resolve(saved,clients,{currentOrigin});
  if(resolved.missing.length||resolved.pending.length)throw Error('Revise esta rota antes de navegar. Ausentes: '+(resolved.missing.join(', ')||'nenhum')+'. Localização pendente: '+(resolved.pending.join(', ')||'nenhuma')+'.');
  const requestGeneration=generation;let start=resolved.start;if(currentOrigin)start=await requestGPS();if(requestGeneration!==generation||document.body.classList.contains('auth-locked'))return false;if(!start)throw Error('A origem salva não está mais disponível. Use a posição atual.');
  resolved=TraxeloPremiumModel.resolve(saved,clients,{currentOrigin});if(resolved.missing.length||resolved.pending.length)throw Error('Os cadastros mudaram durante a abertura. Revise os clientes e suas localizações antes de tentar novamente.');if(!currentOrigin)start=resolved.start;
  cancel();el('origin').value='manual';manualOrigin={...start};manualDraft={...start};originForm.hidden=false;el('routeOriginAddress').value=start.name||'Origem da rota salva';showGpsOrigin();
  selectedIds=new P.IdSet(resolved.points.map(c=>c.id).filter(id=>id!=null));selectionInitialized=true;syncRouteChoices();renderWorkspace();switchTab('mapa');
  const result=await calculate(saved.strategy||'distance',{existing:{start,points:resolved.points,excluded:[],allowUnverified:false,strategy:saved.strategy||'distance'}});
  if(result&&resolved.changed.length)el('routeResult').textContent+=' Posições atualizadas: '+resolved.changed.join(', ')+'.';return !!result;
 }
 window.TraxioRouteUI={calculate,singleClient,cancel,openSaved,getRoute:()=>lastRoute?JSON.parse(JSON.stringify(lastRoute)):null,adHoc:destination=>calculate('avulso',{destination:{...destination}}),retrace:()=>{const existing=lastRoute||preparedRoute;if(!existing){phase('impossible','Calcule uma rota antes de atualizar o trajeto.');return;}return calculate(existing.strategy||'distance',{existing});},state,refresh};
 // Keep keyboard-driven fields visible for any browser implementing VisualViewport.
 let viewportFrame=0;
 function viewportChanged(){cancelAnimationFrame(viewportFrame);viewportFrame=requestAnimationFrame(()=>{const viewport=window.visualViewport;document.documentElement.style.setProperty('--route-visible-height',(viewport?.height||innerHeight)+'px');document.documentElement.style.setProperty('--route-keyboard-inset',Math.max(0,innerHeight-((viewport?.height||innerHeight)+(viewport?.offsetTop||0)))+'px');const focused=document.activeElement;if(focused?.matches('#mapa input,#mapa select'))focused.scrollIntoView({block:'nearest',inline:'nearest'});map?.resize();});}
 window.visualViewport?.addEventListener('resize',viewportChanged);visualViewport?.addEventListener('scroll',viewportChanged);
 document.querySelector('#mapa').addEventListener('focusin',viewportChanged);window.addEventListener('resize',viewportChanged);
 panel.addEventListener('toggle',()=>map?.resize());viewportChanged();lastSignature=signature();refresh();
});

